mock_get_usd_course.side_effect = [76.32, 77.44, ConnectionError]
