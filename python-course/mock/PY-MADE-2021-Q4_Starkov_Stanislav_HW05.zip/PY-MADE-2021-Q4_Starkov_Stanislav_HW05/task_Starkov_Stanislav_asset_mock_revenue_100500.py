mock_asset_class.calculate_revenue.return_value = 100500.0
